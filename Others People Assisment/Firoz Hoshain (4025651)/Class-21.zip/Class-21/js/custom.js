
(function($){
	'use strict'
	//our code
	
	$('h1').css('background','red');
	$('p.contant').show();
	$('h2').html('Welcome To <u>Beautiful</u> Bangladesh');

	//$('p.contant').append(' <b>Good By!</b>');
	$('p.contant').prepend('<b>Good Evening!</b> ');


	$('h1').addClass('xyz');

	$('.container').children('h2').show();

	//$('p').parent('.container').css('background','red');

	$('p.contant b').css({
		fontSize : 20,
		border : '1px solid red',
		backgroundColor : '#32a852',
	});

	$('h1').on('click',function () {
		$('.post').show();
	})
	
	/*$('p.contant b').on('click',function(){
		$('.post').hide();
	})*/

	$('.post button').on('click',function(){
		$('.photo').fadeIn();
	})

	$('.photo i').on('click',function(){
		$('.photo').fadeOut();
		
	})

	/*$('.post button').on('click',function(){
		$('.post').show();
	})*/









	//End
}) (jQuery);