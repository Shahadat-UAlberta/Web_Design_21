
alert('Welcome To' + ' ' + 'jQuery World');

var intro=document.getElementById('intro-text');

intro.style.color='red'



//Make a Watch

function ghori(){
	var time = new Date();
    var ghonta = time.getHours(),
		minit = time.getMinutes(),
		sec	  = time.getSeconds(),
		dinrat= 'PM';

		//am/pm
		if(ghonta<12){
			dinrat='AM';
		}

		//Hour 24-12
		if(ghonta>12){
			ghonta=ghonta-12;
		}

		//Adding 0 when Single Digit

		if(ghonta<10){
			ghonta='0' + ghonta;
		}

		if(minit<10){
			minit='0' + minit;
		}

		if(sec<10){
			sec='0' + sec;
		}

		document.getElementById('clock').innerHTML= ghonta + ':' + minit + ':'+	sec + ' ' + dinrat;
}	
	
setInterval(ghori,1000);	


//Start jQuery

(function($){
	'use strict'

	//$('h1.intro').hide();

	$('h1.intro').addClass('introcolor');

	$('h3.jlib').css('color','#2c3e50');

	$('p.body-text').append('<b> Best of Luck!</b>');

	$('p.body-text').prepend('<b>Good Wishes! </b>');

	$('.body-content').css('background', '#ecf0f1');

	$('button.hide-btn').on('click', function(){
		$('.body-content').hide();
	});

	$('button.show-btn').on('click', function(){
		$('.body-content').show();
	});

	$('button.close-btn').on('click', function(){
		$('.photo').hide();
	});

	$('button.open-btn').on('click', function(){
		$('.photo').show();
	});



	

})(jQuery);


