(function($){
	'use strict'
	
	$('p.content').show();
	$('h2').html('Downloading <em>jQuery</em>');


	$('h1.xyz').removeClass('xyz');
	$('h1').addClass('abc');

	

	$('p.content b').css({ 
		color : '#fbc531',
		backgroundColor : '#353b48',
		fontSize : 20
	 });


	

	$('.post button').on( 'click', function(){
		$('.photo').fadeIn();
	} )

	$('.photo i').on( 'click', function(){
		$('.photo').fadeOut();
	} );

	



	
}) (jQuery);