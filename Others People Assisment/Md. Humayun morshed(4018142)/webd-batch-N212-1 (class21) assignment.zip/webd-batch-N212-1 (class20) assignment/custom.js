

(function($){
//our code

// show / hide 
//$('body').hide();

//$('h1').hide();
$('p.content').show();


//add text 

$('h2').text('we are learning j-query');


// add text withe code 
$('p.content').html(' <em> jQuery </em> is a fast, small, and feature-rich JavaScript library.');


//add text befor/ after
$("p.content").append('  <br><em>goodbye</em>');

$("p.content").prepend(' <b>hello!!!!</b> <br> ');

// class add / remove



//oneline
$('h1.xyz').removeClass('xyz').addClass('abc');

//difernetn line 

//$('h1.xyz').removeClass('xyz')
//$('h1').addClass('abc');


//classs before tag

//$(".container p").hide();

// all p / or specfice p - find method 
//$('.container').children('p').show();

//parent tag $('p.content').parent(".container").hide();

//style 

//$('p.content').parent(".container").css('background', 'red');

+


// muliple css
$('p.content b').css({
	
	color:'#e84118',
	backgroundColor:'#dcdde1',
	fontSize:30,

}

	)

$('h1').on('click', function (){

	$('.post').show()
})


$('p.content b').on('click', function(){

	$('.post').hide()
})

$('.post  button').on('click' , function(){

	$('.photo').fadeIn();
})
	
$('.photo i').on('click' , function(){

	$('.photo').fadeOut();
})
	



//end

})(jQuery);

