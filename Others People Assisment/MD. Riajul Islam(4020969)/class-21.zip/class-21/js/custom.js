(function(){
    'use strict'
    //our code
    $('.menu-icon').on('click',function(){
        $('.menu').fadeOut(200);
        $('.menu').show();
        
    })
    

}) (jQuery)