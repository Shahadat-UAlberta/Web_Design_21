(function($){
	'use strict'
	// Our Code

	//$('h1').hide();
	$('p.content').show();
	$('h2').html('Downloading <em>jQuery</em>');

	$('p.content').prepend('<b>Good Evening!</b> ');

	$('h1.xyz').removeClass('xyz');
	$('h1').addClass('abc');

	//$('.container').find('p').show();

	//$('p.content').parent('.container').css('background', 'red');

	$('p.content b').css({ 
		color : '#fbc531',
		backgroundColor : '#353b48',
		fontSize : 20
	 });


	/*$('h1').on('click', function () {
		$('.post').show();
	})

	$('p.content b').on('click', function(){
		$('.post').hide();
	} );*/

	$('.post button').on( 'click', function(){
		$('.photo').fadeIn();
	} )

	$('.photo i').on( 'click', function(){
		$('.photo').fadeOut();
	} );

	



	// End
}) (jQuery);






















/*(function($){
	'use strict'

	// our code

	//$('h1').hide();
	$('p').show();

	$('h2').text('downloading jquery');

	$('p').prepend('<b>good evening</b> ');

	$('h1,xyz').removeclass('xyz').addclass('abc');

	//$('.container').children('p').hide();

	//$('p.content').parent('.container').hide();

	//$('p.content').parent('.container').css('background','red');

	$('p.content b').css({ 

		color: 'black',
		backgroundColor:'green'

	});

	$('h1').on('click', )

	function () {
		$('.post').show();
	}
	




	//end
}) (jQuery);*/