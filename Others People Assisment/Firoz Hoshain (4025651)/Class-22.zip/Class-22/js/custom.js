
(function($){
	'use strict'
	//use code
	
	$('.menu-icon i').on('click',function(){
		$('.menu').animate({ 'left' : 0});
	})

	$('.menu-close i').on('click',function(){
		$('.menu').animate({ 'left' : -150});
	})

	$('.menu ul li').on('click',function(){
		$('.menu ul ul').slideUp();
		$(this).children('ul').slideDown();
	});

	$('.menu ul ul').parent('li').children('a').append('<i class="fas fa-sort-down"></i>');

	


}) (jQuery)