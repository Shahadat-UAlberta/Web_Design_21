


(function ($){

	'use striet'
	//our code


//$('h1').text('we love bangladesh');

/*$('h1').html('we love <b> bangladesh </b>');*/

$('p').prepend('<b>good bye!</b> ');



//problem
//$('h2').addclass('abc');


//$('.container h1').hide();

//$('.container').children('p').hide();

/*$('p.content b').css({

	color : '#f39c12',
	

});*/

$('p.content b').css({ 
		color : '#fbc531',
		backgroundColor : '#353b48',
		fontSize : 20
	 });
 

/*$('h1').on( 'click', function(){
		$('.post').show();
	})

$('p.content b').on('click', function(){
		$('.post').hide();

})*/



	$('button').on( 'click', function (){
		$('.photo').fadeIn();

	})

	$('.photo i').on('click', function(){
		$('.photo').fadeOut();
	})



}) (jQuery);




