

(function($){
		'Use Strict'
	//Our code start
	$('h1').hide();
	$('h1').show();
	$('h1.text-center').addClass('abc')/*.removeClass('text-center')*/;
	$('h1.abc').text('Hi Everyone');
	$('h2').html('Reading To <b>Javascript</b>');
	$('p').append(' Downloding <b>jQuery</b>')
	$('p').prepend(' Downloding <b>Javascript</b> ');
	$('p b').css({
		color:'red',
		background : 'black',
		cursor : 'pointer'
	});
	/*$('p').parent('.container').css({
		background : 'red'
	})*/


	$('h1.abc').on('click',function () {
		$('.parag').show();
	});

	$('.parag b').on('click',function () {
		$('.con-img').fadeIn();
	});

	$('.con-img i').on('click' , function () {
		$('.parag').hide();
		$('.con-img').fadeOut();

	})


















	// Code End
})(jQuery)